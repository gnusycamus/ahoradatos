 
#!/bin/sh

#Ejecutar el Speaker

java -jar ./bin/Speaker.jar